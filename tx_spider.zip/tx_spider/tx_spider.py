#!/user/bin/env python
# -*-coding:utf-8-*-
# author:chensong time:2019/8/18

import re

import requests
from pyquery import PyQuery
from threading import Thread


class TX:
    def __init__(self, i):
        self.i = i
        self.url = 'https://ke.qq.com/course/list?mt=100{}'.format(self.i)
        self.max_page = re.findall('class="page-btn">(.*?)</a>', requests.get(self.url).text)[-1]

    def parse(self):
        for page in range(1, int(self.max_page)+1):
            doc = PyQuery(self.url + '&page={}'.format(page))
            titles = doc('.market-bd').children('ul li h4 a')
            buy_nums = doc('.market-bd').children('ul li div .item-user')
            prices = doc('.market-bd').children('ul li div .item-price')
            teachers = doc('.market-bd').children('ul li div span .item-source-link')

            for title, buy_num, price, teacher in zip(titles, buy_nums, prices, teachers):
                title = title.text
                buy_num = buy_num.text.strip()
                price = price.text
                teacher = teacher.text
                yield {
                    'title': title,
                    'buy_num': buy_num,
                    'price': price,
                    'teacher': teacher,
                    'page': '第{}页'.format(page)
                }

    def save_info(self):
        for info in self.parse():
            with open('{}.text'.format(self.i), 'a', encoding='utf-8') as f:
                f.write(str(info)+ '\n')


if __name__ == '__main__':
    tt = []
    for i in range(1, 8):
        s = TX(i)
        t_threading = Thread(target=s.save_info)
        t_threading.start()
        tt.append(t_threading)
    for t in tt:
        t.join()


